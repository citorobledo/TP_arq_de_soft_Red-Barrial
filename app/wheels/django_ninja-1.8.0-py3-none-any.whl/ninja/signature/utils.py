import asyncio
import inspect
import re
from sys import version_info
from typing import Any, Callable, Dict, ForwardRef, List, Set

from django.urls import register_converter
from django.urls.converters import UUIDConverter
from pydantic._internal._typing_extra import eval_type_lenient as evaluate_forwardref

from ninja.types import DictStrAny

__all__ = [
    "get_typed_signature",
    "get_typed_annotation",
    "make_forwardref",
    "get_path_param_names",
    "is_async",
]

_FORWARDREF_KWARGS: Dict[str, Any]
_STRING_KWARGS: Dict[str, Any]

if version_info >= (3, 14):  # pragma: no cover
    import annotationlib

    _FORWARDREF_KWARGS = {
        "annotation_format": annotationlib.Format.FORWARDREF,
    }
    _STRING_KWARGS = {
        "annotation_format": annotationlib.Format.STRING,
    }
else:  # pragma: no cover
    _FORWARDREF_KWARGS = {}
    _STRING_KWARGS = {}


def get_typed_signature(call: Callable[..., Any]) -> inspect.Signature:
    "Finds call signature and resolves all forwardrefs"
    signature = inspect.signature(call, **_FORWARDREF_KWARGS)
    globalns = getattr(call, "__globals__", {})
    typed_params = [
        inspect.Parameter(
            name=param.name,
            kind=param.kind,
            default=param.default,
            annotation=get_typed_annotation(param, globalns),
        )
        for param in signature.parameters.values()
    ]
    typed_signature = inspect.Signature(typed_params)
    return typed_signature


def get_typed_annotation(param: inspect.Parameter, globalns: DictStrAny) -> Any:
    annotation = param.annotation
    if isinstance(annotation, str):
        annotation = make_forwardref(annotation, globalns)
    return annotation


def make_forwardref(annotation: str, globalns: DictStrAny) -> Any:
    # NOTE: in future versions of pydantic, the import may be changed to:
    # from pydantic._internal._typing_extra import try_eval_type
    # usage:
    # result, _ = try_eval_type(forward_ref, globalns, globalns)
    forward_ref = ForwardRef(annotation)
    return evaluate_forwardref(forward_ref, globalns, globalns)


def get_path_param_names(path: str) -> Set[str]:
    """turns path string like /foo/{var}/path/{int:another}/end to set {'var', 'another'}"""
    return {item.strip("{}").split(":")[-1] for item in re.findall("{[^}]*}", path)}


def is_async(callable: Callable[..., Any]) -> bool:
    # TODO: Drop this condition once support for <= 3.11 is dropped
    if version_info >= (3, 12):
        return inspect.iscoroutinefunction(callable)
    else:
        return asyncio.iscoroutinefunction(callable)  # pragma: no cover


def has_kwargs(func: Callable[..., Any]) -> bool:
    for param in inspect.signature(func, **_STRING_KWARGS).parameters.values():
        if param.kind == param.VAR_KEYWORD:
            return True
    return False


def get_args_names(func: Callable[..., Any]) -> List[str]:
    "returns list of function argument names"
    return list(inspect.signature(func, **_STRING_KWARGS).parameters.keys())


class UUIDStrConverter(UUIDConverter):
    """Return a path converted UUID as a str instead of the standard UUID"""

    def to_python(self, value: str) -> str:  # type: ignore
        return value  # return string value instead of UUID


register_converter(UUIDStrConverter, "uuidstr")
